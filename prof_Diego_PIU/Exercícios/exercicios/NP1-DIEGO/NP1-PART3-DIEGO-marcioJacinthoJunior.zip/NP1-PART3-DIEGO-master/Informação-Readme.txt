# NP1-PART3-DIEGO

## Copia de site usando elementos/componentes bootstrap

## Integrantes

Grupo composto por:
```
ISAAC SILVA ANTUNES – RA: 02410035429
MARCIO JACINTHO JÚNIOR - RA: 02410036216
MAYKE WEDERSON FERREIRA XAVIER - RA: 02410035006
PAULO RICARDO CASTRO - RA: 02410035351
PEDRO HENRIQUE SILVA RODRIGUES - RA: 02410036151
YURI REIS FAGUNDES - RA: 02410035586
```

## Sobre

* Trabalho que substitui a NP1 - PIU
* Entrega: 23/04/2020

## Links

* [Link no GitHub](https://github.com/ophsr/NP1-PART3-DIEGO "Clique e acesse agora!") - Link do codigo fonte.

## License

Esse projeto está licenciado sob a licença Apache License 2.0 - acesse [LICENSE.md](/LICENSE.md) para mais detalhes.
